//let's load all extensions settings
var loadOptions = function() {
	
}

//apply options to nessesary fields
var setOptionsAtPage = function(options) {

}

var saveOptions = function() {

}

var restoreOptions = function() {
	
}