chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
   if (request.message === "setIconEnable")
   {
     chrome.browserAction.setIcon({ path: "images/icon_enabled.png" });
   }
});
